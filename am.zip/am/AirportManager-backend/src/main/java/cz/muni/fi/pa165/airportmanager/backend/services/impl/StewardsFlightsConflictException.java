
package cz.muni.fi.pa165.airportmanager.backend.services.impl;

import cz.muni.fi.pa165.airportmanager.transferobjects.StewardTO;

/**
 *
 * @author Chorke
 */
public class StewardsFlightsConflictException extends RuntimeException{
    
    private final StewardTO steward;

    public StewardsFlightsConflictException(StewardTO steward) {
        this.steward = steward;
    }

    public StewardsFlightsConflictException(StewardTO steward, String message) {
        super(message);
        this.steward = steward;
    }

    public StewardsFlightsConflictException(StewardTO steward, String message, Throwable cause) {
        super(message, cause);
        this.steward = steward;
    }

    public StewardTO getSteward() {
        return steward;
    }
}
