/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.muni.fi.pa165.airportmanager.backend.services.impl;

import cz.muni.fi.pa165.airportmanager.transferobjects.AirplaneTO;

/**
 *
 * @author Chorke
 */
public class AirplanesFlightsConflictException extends RuntimeException{
    
    private final AirplaneTO airplane;

    public AirplanesFlightsConflictException(AirplaneTO airplane, String message, Throwable cause) {
        super(message, cause);
        this.airplane = airplane;
    }

    public AirplanesFlightsConflictException(AirplaneTO airplane, String message) {
        super(message);
        this.airplane = airplane;
    }

    public AirplanesFlightsConflictException(AirplaneTO airplane) {
        this.airplane = airplane;
    }

    public AirplaneTO getAirplane() {
        return airplane;
    }
}
